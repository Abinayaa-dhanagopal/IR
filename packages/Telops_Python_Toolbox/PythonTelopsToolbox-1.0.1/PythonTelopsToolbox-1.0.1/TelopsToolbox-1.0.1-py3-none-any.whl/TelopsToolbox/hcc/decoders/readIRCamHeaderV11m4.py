from TelopsToolbox.hcc.decoders.decoder import decoder


def read_ircam_header_v11m4(bytes_input):
    """
     Decode header portion of an IRCam image
    Header = readIRCamHeaderV12m1(bytes_input)
    :param bytes_input: an array of headers format <Nframes x Nbytes>
    :return: header dictionnary containing necessary info

    DO NOT MANUALLY MODIFY THIS CODE!
    Modify the generateIRCamHeaderMatlabLib.m script instead. (?)
    """

    # Initialization

    # Initial definition position
    ptr = 0

    # Decoding

    # Attributing a vector for every field
    h_ini = {"Signature": 0}
    h_ini["Signature"], ptr = decoder(bytes_input, 'c2', ptr)
    h_ini["DeviceXMLMinorVersion"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["DeviceXMLMajorVersion"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["ImageHeaderLength"], ptr = decoder(bytes_input, 'H', ptr)
    # skip reserved word location
    ptr += 2

    h_ini["FrameID"], ptr = decoder(bytes_input, 'I', ptr)
    h_ini["DataOffset"], ptr = decoder(bytes_input, 'f', ptr)
    h_ini["DataExp"], ptr = decoder(bytes_input, 'b', ptr)
    # skip reserved word location
    ptr += 7

    h_ini["ExposureTime"], ptr = decoder(bytes_input, 'I', ptr)
    h_ini["CalibrationMode"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["BPRApplied"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["FrameBufferMode"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["CalibrationBlockIndex"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["Width"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["Height"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["OffsetX"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["OffsetY"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["ReverseX"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["ReverseY"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["TestImageSelector"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["SensorWellDepth"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["AcquisitionFrameRate"], ptr = decoder(bytes_input, 'I', ptr)
    h_ini["TriggerDelay"], ptr = decoder(bytes_input, 'f', ptr)
    h_ini["TriggerMode"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["TriggerSource"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["IntegrationMode"], ptr = decoder(bytes_input, 'B', ptr)
    # skip reserved word location
    ptr += 1

    h_ini["AveragingNumber"], ptr = decoder(bytes_input, 'B', ptr)
    # skip reserved word location
    ptr += 2

    h_ini["ExposureAuto"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["AECResponseTime"], ptr = decoder(bytes_input, 'f', ptr)
    h_ini["AECImageFraction"], ptr = decoder(bytes_input, 'f', ptr)
    h_ini["AECTargetWellFilling"], ptr = decoder(bytes_input, 'f', ptr)
    # skip reserved word location
    ptr += 3

    h_ini["FWMode"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["FWSpeedSetpoint"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["FWSpeed"], ptr = decoder(bytes_input, 'H', ptr)
    # skip reserved word location
    ptr += 20

    h_ini["POSIXTime"], ptr = decoder(bytes_input, 'I', ptr)
    h_ini["SubSecondTime"], ptr = decoder(bytes_input, 'I', ptr)
    h_ini["TimeSource"], ptr = decoder(bytes_input, 'B', ptr)
    # skip reserved word location
    ptr += 2

    h_ini["GPSModeIndicator"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["GPSLongitude"], ptr = decoder(bytes_input, 'i', ptr)
    h_ini["GPSLatitude"], ptr = decoder(bytes_input, 'i', ptr)
    h_ini["GPSAltitude"], ptr = decoder(bytes_input, 'i', ptr)
    h_ini["FWEncoderAtExposureStart"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["FWEncoderAtExposureEnd"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["FWPosition"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["ICUPosition"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["NDFilterPosition"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["EHDRIExposureIndex"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["FrameFlag"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["PostProcessed"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["SensorTemperatureRaw"], ptr = decoder(bytes_input, 'H', ptr)
    h_ini["AlarmVector"], ptr = decoder(bytes_input, 'I', ptr)
    # skip reserved word location
    ptr += 16

    h_ini["ExternalBlackBodyTemperature"], ptr = decoder(bytes_input, 'f', ptr)
    h_ini["TemperatureSensor"], ptr = decoder(bytes_input, 'h', ptr)
    # skip reserved word location
    ptr += 2

    h_ini["TemperatureInternalLens"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["TemperatureExternalLens"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["TemperatureInternalCalibrationUnit"], ptr = decoder(bytes_input, 'h', ptr)
    # skip reserved word location
    ptr += 10

    h_ini["TemperatureExternalThermistor"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["TemperatureFilterWheel"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["TemperatureCompressor"], ptr = decoder(bytes_input, 'h', ptr)
    h_ini["TemperatureColdFinger"], ptr = decoder(bytes_input, 'h', ptr)
    # skip reserved word location
    ptr += 24

    h_ini["CalibrationBlockPOSIXTime"], ptr = decoder(bytes_input, 'I', ptr)
    h_ini["ExternalLensSerialNumber"], ptr = decoder(bytes_input, 'I', ptr)
    h_ini["ManualFilterSerialNumber"], ptr = decoder(bytes_input, 'I', ptr)
    h_ini["SensorID"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["PixelDataResolution"], ptr = decoder(bytes_input, 'B', ptr)
    # skip reserved work location
    ptr += 9

    h_ini["DeviceCalibrationFilesMajorVersion"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["DeviceCalibrationFilesMinorVersion"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["DeviceCalibrationFilesSubMinorVersion"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["DeviceDataFlowMajorVersion"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["DeviceDataFlowMinorVersion"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["DeviceFirmwareMajorVersion"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["DeviceFirmwareMinorVersion"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["DeviceFirmwareSubMinorVersion"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["DeviceFirmwareBuildVersion"], ptr = decoder(bytes_input, 'B', ptr)
    h_ini["ActualizationPOSIXTime"], ptr = decoder(bytes_input, 'I', ptr)
    h_ini["DeviceSerialNumber"], ptr = decoder(bytes_input, 'I', ptr)
    # skip reserved word location
    ptr += 4

    return h_ini
