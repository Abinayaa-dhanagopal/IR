import struct
import warnings


def write_ircam_header_v6m1(fid, header):
    """
    Write the header structure of an IRCDEV image into file pointed by fid.
        write_ircam_header_v6m1(fid, header)

        INPUT
            A file descriptor with current position pointing to the beginning of the header.

        "auto-generated function for header writing.
         based on xml file definition version 6.1.12"

        DO NOT MANUALLY MODIFY THIS CODE!

    """

    datasize = 2

    init_offset = fid.tell()
    fid.write(struct.pack('<cc', bytes(header["Signature"][0], 'utf-8'), bytes(header["Signature"][1], 'utf-8')))
    fid.write(struct.pack('<B', header["DeviceXMLMinorVersion"]))
    fid.write(struct.pack('<B', header["DeviceXMLMajorVersion"]))
    fid.write(struct.pack('<H', header["ImageHeaderLength"]))
    # skip reserved word location
    fid.write(struct.pack('<BB', 0, 0))

    fid.write(struct.pack('<f', header["DataOffset"]))
    fid.write(struct.pack('<f', header["DataLSB"]))
    # skip reserved word location
    fid.write(struct.pack('<BBBBBBBB', 0, 0, 0, 0, 0, 0, 0, 0))

    fid.write(struct.pack('<f', header["ExposureTime"]))
    fid.write(struct.pack('<B', header["CalibrationMode"]))
    fid.write(struct.pack('<B', header["BPREnabled"]))
    fid.write(struct.pack('<B', header["FrameBufferMode"]))
    # skip reserved word location
    fid.write(struct.pack('<B', 0))

    fid.write(struct.pack('<H', header["Width"]))
    fid.write(struct.pack('<H', header["Height"]))
    fid.write(struct.pack('<H', header["OffsetX"]))
    fid.write(struct.pack('<H', header["OffsetY"]))
    fid.write(struct.pack('<B', header["FlipLR"]))
    fid.write(struct.pack('<B', header["FlipUD"]))
    fid.write(struct.pack('<B', header["TestImageSelector"]))
    fid.write(struct.pack('<B', header["SensorWellDepth"]))
    fid.write(struct.pack('<f', header["AcquisitionFrameRate"]))
    fid.write(struct.pack('<f', header["TriggerDelay"]))
    fid.write(struct.pack('<B', header["TriggerMode"]))
    fid.write(struct.pack('<B', header["TriggerSource"]))
    fid.write(struct.pack('<B', header["IntegrationMode"]))
    # skip reserved word location
    fid.write(struct.pack('<B', 0))

    fid.write(struct.pack('<H', header["AveragingNumber"]))
    fid.write(struct.pack('<B', header["ExposureMode"]))
    fid.write(struct.pack('<B', header["ExposureAuto"]))
    fid.write(struct.pack('<f', header["AECResponseTime"]))
    fid.write(struct.pack('<f', header["AECWellFillingTarget"]))
    fid.write(struct.pack('<f', header["AECHotSpotMaxSize"]))
    fid.write(struct.pack('<B', header["AECPriorityMode"]))
    # skip reserved word location
    fid.write(struct.pack('<BB', 0, 0))

    fid.write(struct.pack('<B', header["SFWMode"]))
    fid.write(struct.pack('<f', header["SFWSpeedSetpoint"]))
    # skip reserved word location
    fid.write(struct.pack('<BBBBBBBBBBBBBBBBBBBB', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0))

    fid.write(struct.pack('<I', header["POSIXTime"]))
    fid.write(struct.pack('<I', header["SubSecondTime"]))
    fid.write(struct.pack('<B', header["TimeSource"]))
    # skip reserved word location
    fid.write(struct.pack('<BB', 0, 0))

    fid.write(struct.pack('<B', header["GPSModeIndicator"]))
    fid.write(struct.pack('<i', header["GPSLongitude"]))
    fid.write(struct.pack('<i', header["GPSLatitude"]))
    fid.write(struct.pack('<i', header["GPSAltitude"]))
    fid.write(struct.pack('<H', header["SFWEncoderAtExposureStart"]))
    fid.write(struct.pack('<H', header["SFWEncoderAtExposureEnd"]))
    fid.write(struct.pack('<B', header["SFWPosition"]))
    fid.write(struct.pack('<B', header["ICUPosition"]))
    fid.write(struct.pack('<B', header["NDFilterPosition"]))
    fid.write(struct.pack('<B', header["EHDRIExposureIndex"]))
    fid.write(struct.pack('<B', header["ImageGating"]))
    # skip reserved word location
    fid.write(struct.pack('<B', 0))

    fid.write(struct.pack('<H', header["SensorTemperatureRaw"]))
    fid.write(struct.pack('<H', header["AnalogInputChannel1"]))
    fid.write(struct.pack('<H', header["AnalogInputChannel2"]))
    fid.write(struct.pack('<H', header["AnalogInputChannel3"]))
    fid.write(struct.pack('<H', header["AnalogInputChannel4"]))
    # skip reserved word location
    fid.write(struct.pack('<BBBBBBBBBBBB', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0))

    fid.write(struct.pack('<f', header["ExternalBlackBodyTemperature"]))
    fid.write(struct.pack('<h', header["TemperatureSensor"]))
    # skip reserved word location
    fid.write(struct.pack('<BB', 0, 0))

    fid.write(struct.pack('<h', header["TemperatureInternalLens"]))
    fid.write(struct.pack('<h', header["TemperatureExternalLens"]))
    fid.write(struct.pack('<h', header["TemperatureInternalCalibrationUnit"]))
    fid.write(struct.pack('<h', header["TemperatureLCCThermistor"]))
    fid.write(struct.pack('<h', header["TemperatureROICFPGA"]))
    fid.write(struct.pack('<h', header["TemperatureROICPCB"]))
    fid.write(struct.pack('<h', header["TemperatureCameraLinkFPGA"]))
    fid.write(struct.pack('<h', header["TemperatureCameraLinkPCB"]))
    fid.write(struct.pack('<h', header["TemperatureExternalThermistor"]))
    fid.write(struct.pack('<h', header["TemperatureSpectralFilterWheel"]))
    fid.write(struct.pack('<h', header["TemperatureCompressor"]))
    fid.write(struct.pack('<h', header["TemperatureColdFinger"]))
    fid.write(struct.pack('<f', header["SaturatedPixelsRatio"]))
    # skip reserved word location
    fid.write(struct.pack('<BBBB', 0, 0, 0, 0))

    fid.write(struct.pack('<H', header["PostProcessingInfo"]))
    # skip reserved word location
    fid.write(struct.pack('<BBBBBB', 0, 0, 0, 0, 0, 0))

    fid.write(struct.pack('<H', header["RawSaturationLevel"]))
    # skip reserved word location
    fid.write(struct.pack('<BB', 0, 0))

    fid.write(struct.pack('<H', header["SensorWidth"]))
    fid.write(struct.pack('<H', header["SensorHeight"]))
    fid.write(struct.pack('<I', header["FactoryCalibrationDataSetPOSIXTime"]))
    fid.write(struct.pack('<I', header["ExternalLensID"]))

    diff_dmn = 20 - len(header["DeviceModelName"])
    for i in range(0, len(header["DeviceModelName"])):
        fid.write(struct.pack('<c', bytes(header["DeviceModelName"][i], 'utf-8')))
    for i in range(0, diff_dmn):
        fid.write(struct.pack('<x'))  # x fait du padding :)

    diff_dfv = 8 - len(header["DeviceFirmwareVersion"])
    for i in range(0, len(header["DeviceFirmwareVersion"])):
        fid.write(struct.pack('<c', bytes(header["DeviceFirmwareVersion"][i], 'utf-8')))
    for i in range(0, diff_dfv):
        fid.write(struct.pack('<x'))

    diff_di = 8 - len(header["DeviceID"])
    for i in range(len(header["DeviceID"])):
        fid.write(struct.pack('<c', bytes(header["DeviceID"][i], 'utf-8')))
    for i in range(0, diff_di):
        fid.write(struct.pack('<x'))

    # Check if versions are compatible
    if header["DeviceXMLMajorVersion"] != 6:
        raise FileNotFoundError('This function supports XML Version 6m1, but the header H asks for Version {}.{}'
                                .format(header["DeviceXMLMajorVersion"], header["DeviceXMLMinorVersion"]))
    if header["DeviceXMLMinorVersion"] != 1:
        warnings.warn('TelopsXmlMinorVersionMismatch : '
                      'This function supports XML version 6m1, but the header asks for version {}.{}'
                      .format(header["DeviceXMLMjaorVersion"], header["DeviceXMLMinorVersion"]))

    curr_pos = fid.tell() - init_offset
    # skip to the beginning of the data
    offset = header["ImageHeaderLength"] - curr_pos
    for i in range(0, offset):
        fid.write(struct.pack('<B', 0))
