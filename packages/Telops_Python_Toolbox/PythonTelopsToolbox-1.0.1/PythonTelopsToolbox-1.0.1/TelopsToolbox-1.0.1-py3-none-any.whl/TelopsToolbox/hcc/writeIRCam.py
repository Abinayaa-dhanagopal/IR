import numpy as np
import os
from TelopsToolbox.hcc.convertHeader import convert_header
from TelopsToolbox.hcc.writeIRCamHeaderB import write_ircam_header_b


def write_ircam(header, data, filename, nframes_per_file=0, special_pixel_map=np.zeros((1, 1)),
                pixel_mapping='Fixed'):
    """
    Write a frame sequence to file(s) in the Telops IRCam format (.hcc).

        n_writeIRCam(Header, data, filename, nframes_per_file, saturated_pixels, bad_pixels)

        Write a frame sequence to a single file or to a sequence of files using the Telops infrared camera format

        The pixel values must be along columns. To obtain such an array from a 3D matrix with dimensions
        (nframes, width, height), one must reshape the data like this:
            data = unfold_image(header[0], data_im)

        [...] = n_writeIRCam(..., 'Param1', value1, 'Param2', value2, ...) uses parameter-value pairs to control the
        writing operation.

            Parameter name      Value
            --------------      -----
            'pixel_mapping'     The method used to map the (real) pixel values to uint16 format in the binary image
                                part of the .hcc file. Possible methods are:
                                'AutomaticImage'      (adjusted individually for each image),
                                'AutomaticSequence'   (adjusted globally for the whole sequence), and
                                'Fixed'               (taken from the image header).
                                The default value is 'Fixed'.

        INPUTS
            header  : vector of header structures in the IRCam format
            data    : (num frames, Width x Height) matrix of data to write
            nframes_per_file [optional]
                    : specifies the number of frames to write per file; if > 1,
                      files will be appended with a sequence number
            saturated_pixels [optional]
                    : logical matrix (same size as "data") of saturation statuses,
                      only available for XML >= 10; their value is forced to xFFFF;
                      if not supplied, no pxel is considered saturated
            bad_pixels       [optional]
                    : logical matrix (same size as "data") of bad pixels statuses,
                      only available for XML >= 10; their value is forced to xFFFE
                      when header field "BPRApplied" is false; if not supplied, all
                      nans are still considered bad pixels

    Copyright Telops 2009

    """

    # Initialisation
    datasize = 2   # number of bytes per sample

    nframes = data.shape[0]

    if nframes_per_file == 0:
        nframes_per_file = nframes

    if np.array_equal(special_pixel_map, np.zeros((1, 1))):
        special_pixel_map = np.zeros(data.shape)
    elif special_pixel_map.shape != data.shape:
        raise Exception('The size of the special pixel map is different from the size of the data.')

    # add nans to BadPixels
    special_pixel_map[np.isnan(data)] = 14

    # only valid pixels are considered to compute DataOffset and DataExp/DataLSB
    # - XML >= 10.0 only
    valid_pixels = np.logical_or(np.logical_not(special_pixel_map), header["DeviceXMLMajorVersion"][0] < 10)

    # définition des valeurs binaires (uint16) extrêmes
    count_min = 0
    count_max = 0
    if pixel_mapping == 'AutomaticImage' or pixel_mapping == 'AutomaticSequence':
        if header["DeviceXMLMajorVersion"][0] >= 10:
            # exclusion de la valeur x0000 afin d'assurer qu'aucune saturation basse n'est présente
            count_min = int('0x0000', 0) + 1
            # exclusion des valeurs supérieures à xFFF0, utilisées comme statuts
            # exclusion de la valeur xFFF0 afin d'assurer qu'aucune saturation haute n'est présente
            count_max = int('0xFFF0', 0) - 1
        else:
            count_min = 0
            count_max = 2**16 - 1

    # établissement des valeurs d'offset et de quantification, pour chaque image
    if pixel_mapping == 'AutomaticSequence':
        data_min = np.amin(data[valid_pixels])
        data_max = np.amax(data[valid_pixels])
        if (np.log2((data_max - data_min) / (count_max - count_min))) == float("-inf"):
            data_exp = 0
        else:
            data_exp = int(np.ceil(np.log2((data_max - data_min) / (count_max - count_min))))
        data_offset = data_min - 2**data_exp
    elif pixel_mapping == 'AutomaticImage':
        data_exp = np.zeros((nframes, 1))
        data_offset = np.zeros((nframes, 1))
        for i in range(0, nframes):
            data_min = np.amin(data[i, valid_pixels[i, :]])
            data_max = np.amax(data[i, valid_pixels[i, :]])
            if (np.log2((data_max - data_min) / (count_max - count_min))) == float("-inf"):
                data_exp[i] = 0
            else:
                data_exp[i] = int(np.ceil(np.log2((data_max - data_min) / (count_max - count_min))))
            data_offset[i] = data_min - 2 ** data_exp[i]
    elif pixel_mapping == 'Fixed':
        if header["DeviceXMLMajorVersion"][0] >= 6:
            data_offset = header["DataOffset"]
            data_exp = header["DataExp"]
        else:
            data_offset = header["CalibratedDataOffset"]
            data_exp = np.round(np.log(header["CalibratedDataLSBValue"]) / np.log(2))
    else:
        # data_offset = 0
        # data_exp = 0
        raise Exception('unknown pixel_mapping. The available pixel_mapping are AutomaticSequence, '
                        'AutomaticImage and Fixed')

    if data_offset.shape == (1, 1):
        data_offset = np.ones((nframes, 1)) * data_offset
    if data_exp.shape == (1, 1):
        data_exp = np.ones((nframes, 1)) * data_exp

    # assignation des valeurs d'en-têtes
    if header["DeviceXMLMajorVersion"][0] == 5:
        header["CalibratedDataOffset"] = data_offset
        header["CalibratedDataLSBValue"] = np.power(2, data_exp)   # 2.^data_exp
        header["CalibratedDataOffset"] = np.asarray(np.reshape(header["CalibratedDataOffset"], (1, -1))[0],
                                                    dtype=header["CalibratedDataOffset"].dtype)
        header["CalibratedDataLSBValue"] = np.asarray(np.reshape(header["CalibratedDataLSBValue"], (1, -1))[0],
                                                      dtype=header["CalibratedDataLSBValue"].dtype)
    elif 6 <= header["DeviceXMLMajorVersion"][0] <= 7:
        # même chose que 6 <= header["DeviceXMLMajorVersion"][0] and header["DeviceXMLMajorVersion"][0] <= 7
        header["DataOffset"] = data_offset
        header["DataLSB"] = np.power(2, data_exp)   # 2.^data_exp
        header["DataOffset"] = np.asarray(np.reshape(header["DataOffset"],
                                                     (1, -1))[0], dtype=header["DataOffset"].dtype)
        header["DataLSB"] = np.asarray(np.reshape(header["DataLSB"], (1, -1))[0], dtype=header["DataLSB"].dtype)
    elif 10 <= header["DeviceXMLMajorVersion"][0]:
        header["DataOffset"] = data_offset
        header["DataExp"] = np.array(data_exp, dtype='int8')
        header["DataOffset"] = np.asarray(np.reshape(header["DataOffset"],
                                                     (1, -1))[0], dtype=header["DataOffset"].dtype)
        header["DataExp"] = np.asarray(np.reshape(header["DataExp"], (1, -1))[0], dtype=header["DataExp"].dtype)

    # Écriture du fichier
    nfiles = int(np.ceil(nframes / nframes_per_file))

    frame_idx = 0
    frames_remaining = nframes

    if header["DeviceXMLMajorVersion"][0] < 6 and not(data.dtype == np.uint16 or data.type == np.int16):
        raise Exception('The data must be 16-bit integers')

    # multiWaitbar
    for i in range(0, nfiles):
        # if the number of files to write is > 1, serialize the file names
        if nfiles > 1:
            path, ext = os.path.splitext(filename)
            seq_name = "{}_{}{}".format(path, i, ext)
        else:
            seq_name = filename

        fid = open(seq_name, 'wb')

        converted_header = convert_header(header)

        for j in range(0, np.amin([frames_remaining, nframes_per_file])):
            # normalisation des valeurs de pixels, plus quantification et conversion
            if header["DeviceXMLMajorVersion"][0] >= 6:
                this_data = (data[frame_idx, :] - data_offset[frame_idx]) / 2 ** int(data_exp[frame_idx])
            else:
                this_data = data[frame_idx, :]

            # gestion des pixels saturés / défectueux
            # - XML >= 10.0
            # - sauf "CalibrationMode" RAW0
            if header["DeviceXMLMajorVersion"][0] >= 10 and header["CalibrationMode"][frame_idx] != 0:
                idx_special_pixel = special_pixel_map[frame_idx, :] != 0
                this_data[idx_special_pixel] = special_pixel_map[frame_idx, idx_special_pixel] + int('0xFFF0', 0)

            # écriture de l'en-tête
            write_ircam_header_b(fid, converted_header[frame_idx])

            nbytes_written = fid.write(this_data.astype(np.uint16).tostring()) / 2
            if nbytes_written != this_data.shape[0]:
                raise ValueError('Write problem ({} bytes written, expected {} bytes)'
                                 .format(datasize * nbytes_written, datasize * this_data.shape[0]))

            # update multiWaitbar

            frame_idx += 1

        fid.close()

        frames_remaining = frames_remaining - nframes_per_file
