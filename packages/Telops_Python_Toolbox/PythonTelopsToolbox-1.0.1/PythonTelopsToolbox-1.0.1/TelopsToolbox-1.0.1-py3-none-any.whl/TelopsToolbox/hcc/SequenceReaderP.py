import os
import datetime as dt
import math
import warnings
import numpy as np
from TelopsToolbox.hcc.readIRCamHeaderB import read_ircam_header_b
from TelopsToolbox.hcc.filterBadPixels import filter_bad_pixels
from natsort import natsorted
import time

"""
SequenceReaderP     Classe de lecture de fichiers .hcc utilisant memmapfile.

Auteurs : Simon Savary, Pierre Tremblay ing.
Traducteur : BTU
                               
    Copyright Telops 2019 (?)
    $Revision: 214 $
    $Author: nfoussats $
    $LastChangedDate: 2021-07-01 16:53:40 -0400 (Thu, 01 Jul 2021) $
    $HeadURL: http://einstein/svn/python/Dev/TelopsToolbox/hcc/SequenceReaderP.py $
"""


class SequenceReaderP:
    highest_valid_value_code = int("FFF0", 16)
    lower_digital_saturation = 1
    upper_digital_saturation = 2
    special_tag_3 = 3
    special_tag_4 = 4
    special_tag_5 = 5
    special_tag_6 = 6
    special_tag_7 = 7
    special_tag_8 = 8
    special_tag_9 = 9
    blank_image_translation = 10
    bad_emissivity_correction = 11
    under_calibration_range = 12
    over_calibration_range = 13
    bad_pixel_tag = 14  # Code de pixel défectueux
    saturated_pixel_tag = 15  # Code de pixel saturé

    def __init__(self, file_names):
        # initialisation
        self.filename = file_names  # Nom du/des fichier(s)

        self.spassignment_method = 'max'  # Méthode d'attribution des pixels saturés
        self.bpassignment_method = 'median'  # Méthode d'attribution des pixels défectueux
        # tous les paramètres suivants sont définis à partir d'autres méthodes

        self.header = None  # En-tête de la première image
        self.width = None  # Largeur des images
        self.height = None  # Hauteur des images

        self.size_on_disk = None  # Taille sur disque (en octets)
        self.size_in_ram = None  # Taille en mémoire (en octets)
        self.eachfile_size_on_disk = None  # Paramètre que j'ajoute pour calculer le size de chaque frame
        self.length = None  # Nombre d'images
        self.memmap = None  # Vecteur de "memory map" pour chaque fichier
        self.format = None  # Vecteur de formats d "memory map" pour chaque fichier
        self.private_length = None  # Vecteur de nombre d'images pour chaque fichier

        self.open_file(file_names)

    def open_file(self, file_names):
        # Initialisation de la classe et d'un objet "memmapfile" pour chaque fichier
        # pas besoin de faire la conversion, file_names est un tuple contenant le nom de chaque fichier sélectionné
        # extraction du chemin
        if type(file_names) != str:
            file_path = os.path.dirname(file_names[0])
        else:
            file_path = os.path.dirname(file_names)
            file_names = [file_names]
        # construction de la structure retournée par la fonction "dir"
        files = []  # va contenir le ou les dictionnaires d'information de chaque fichier
        files_just_names = []
        for i in range(0, len(file_names)):
            files_just_names.append(os.path.basename(file_names[i]))
            t = os.path.getmtime(file_names[i])
            date = dt.datetime.fromtimestamp(t)
            # pour calculer la date as serial number
            date_serial = date.toordinal() + 367
            file_dic = {"name": os.path.basename(file_names[i]),
                        "folder": os.path.dirname(file_names[i]),
                        "date": date,
                        "bytes": os.path.getsize(file_names[i]),
                        "isdir": os.path.isdir(file_names[i]),
                        "datenum": date_serial}

            # vérifier si l'attribut "folder" est présent dans le dictionnaire, l'ajouter si non
            if "folder" not in file_dic:
                file_dic["folder"] = file_path

            files.append(file_dic)

        # tri dans l'ordre naturel
        # ex : {'a1.txt', 'a10.txt', 'a2.txt'} devient {'a1.txt', 'a2.txt', 'a10.txt'}
        files_sorted = []
        for i in range(0, len(files)):
            files_sorted.append(0)
        files_just_names_sorted = natsorted(files_just_names)
        for dic_index in range(0, len(files)):
            current_name = files[dic_index]["name"]
            for name_index in range(0, len(files_just_names_sorted)):
                if files_just_names_sorted[name_index] == current_name:
                    files_sorted[name_index] = files[dic_index]

        # lecture du nombre d'images et de l'en-tête de la première image
        self.private_length, self.header = self.peek(files)

        # conversion
        for i in range(0, len(self.private_length)):
            self.private_length[i] = math.floor(self.private_length[i])

        # récupération des paramètres de taille d'image
        h = self.header
        self.width = h["Width"][0]
        self.height = h["Height"][0]
        self.length = self.get_length()

        # calcul de la taille sur disque
        # - 2 octets par pixel
        # - 2 lignes allouées à l'en tête
        self.size_on_disk = 2 * int(self.length) * int(self.width) * (int(self.height) + 2)
        self.eachfile_size_on_disk = []
        for i in range(0, len(self.private_length)):
            self.eachfile_size_on_disk.append(2 * int(self.private_length[i]) * int(self.width)
                                              * (int(self.height) + 2))

        # calcul de la taille en mémoire
        # - 4 octets par pixel (format "single")
        # - 2 octets par pixel pour l'en-tête
        # - 2 lignes allouées à l'en-tête
        self.size_in_ram = (4 * int(self.length) * int(self.width) * int(self.height)) \
                           + (2 * int(self.length) * int(self.width) * 2)

        # associer chaque fichier à la mémoire à l'aide de "memmapfile"
        # - aucune interprétation des en-têtes
        self.format = []
        self.memmap = []
        for i in range(0, len(files)):
            # données lues en vecteurs colonne
            offset_header = 0
            offset_data = 2 * self.width * 2
            frame_size = int(self.eachfile_size_on_disk[i] / self.private_length[i])
            self.memmap.append([])
            self.memmap[i].append({"Header": []})
            self.memmap[i].append({"Data": []})
            counter = 0
            with open(file_names[i], mode='rb') as file:
                for _ in range(0, self.private_length[i]):
                    header_raw = np.fromstring(file.read(2 * int(self.width) * 2), dtype=np.uint8)
                    data_raw = np.fromstring(file.read(int(self.width) * int(self.height) * 2), dtype=np.uint16)
                    self.memmap[i][0]["Header"].append(header_raw[:, np.newaxis])
                    self.memmap[i][1]["Data"].append(data_raw[:, np.newaxis])

    @staticmethod
    def peek(files):  # files est la liste de dictionnaires des fichiers ordonné dans l'ordre naturel
        # Lecture du nombre d'images dans la séquence et lecture de l'en-tête de la première image

        # définition du nombre d'octets par pixel
        octets_par_pixel = 2
        # définition de la plus petite largeur d'image permise
        largeur_minimale = 64
        # définition du nombre de lignes occupées par l'en-tête sur les images de plus petite largeur
        lignes_par_entete = 2
        # sélection de la première image
        ff = 0

        # nom complet du permier fichier de la séquence
        full_filename = files[ff]["folder"] + "/" + files[ff]["name"]

        # ouverture du fichier
        hcc_file = open(full_filename, 'rb')

        # lecture de l'en-tête de la première image
        # - la taille est la même depuis XML 1.0
        bytes_toread = hcc_file.read(octets_par_pixel * largeur_minimale * lignes_par_entete)
        bytes_toread_memmap = np.memmap(full_filename, dtype=np.uint8, mode='r',
                                        shape=(1, octets_par_pixel * largeur_minimale * lignes_par_entete))

        # fermeture du fichier
        hcc_file.close()

        # conversion de l'en-tête en structure
        first_h_memmaptest = read_ircam_header_b(bytes_toread_memmap)

        # extraction des paramètres de taille d'image
        height = first_h_memmaptest["Height"][0]
        width = first_h_memmaptest["Width"][0]

        # calcul des nombres d'images contenues dans chacun des fichiers sélectionnés
        # - "n_frames" est un vecteur ligne <1 x n_fichiers>
        # - l'en-tête occupe "lignes_par_entete" lignes
        n_frames = []
        for i in range(0, len(files)):
            bytes_size = os.path.getsize(files[i]["folder"] + "/" + files[i]["name"])
            n_frames_filei = bytes_size / (octets_par_pixel * width * (height + lignes_par_entete))
            n_frames.append(n_frames_filei)

        return n_frames, first_h_memmaptest

    def frame(self, frame_idx, pixel_idx=(), only_h=0):
        # Lecture des en-têtes et des images d'indices "frame_idx"
        # - lecture des images optionnelle (car en second argument de sortie)
        # - "f" en uint16
        # - gestion multi-fichiers - "frame_idx" est partagé sur les différents fichiers
        # - optionnellement, seulement les pixels d'indices "pixel_idx" sont lus

        # initialisation
        f = []

        # validation de la disponibilité des images demandées
        # frame_idx est un array contenant les indexs des frames qu'on veut lire

        '''
        frames2del = []
        for frame in range(0, len(frame_idx)):
            if self.length <= frame_idx[frame] or frame_idx[frame] < 0:
                frames2del.append(frame)
        frame_idx = np.delete(frame_idx, frames2del)
        '''
        if frame_idx.size == 0:  # aucun indice valide
            warnings.warn("SequenceReaderP:frame:emptyframeidx : Requested images are not available.")
            return None

        if len(pixel_idx) == 0:  # si le user ne spécifie pas de pixels à lire, on lit tous les pixels
            pixel_idx = np.linspace(0, int(self.width) * int(self.height) - 1, int(self.width) * int(self.height),
                                    dtype=int)

        # validation de la disponibilité des pixels demandés
        # pixel_idx est un array contenant les indexs des pixels qu'on veut runner
        pixels2del = []
        for pixel in range(0, len(pixel_idx)):
            if int(self.width) * int(self.height) <= pixel_idx[pixel] or pixel_idx[pixel] < 0:
                pixels2del.append(pixel)
        pixel_idx = np.delete(pixel_idx, pixels2del)

        if pixel_idx.size == 0:  # aucun indice valide
            warnings.warn("SequenceReaderP:frame:emptypixelidx : Requested pixels are not available")
            return None

        # association indices d'image vs fichier
        frames_cumsum = np.cumsum(self.private_length)
        for cum in range(0, len(frames_cumsum)):
            frames_cumsum[cum] -= 1

        file_mask = np.zeros((len(self.filename), frame_idx.size), dtype=int)
        for i in range(0, len(frames_cumsum)):
            for j in range(0, frame_idx.size):
                if frame_idx.size > 1:
                    file_mask[i, j] = frame_idx[j] <= frames_cumsum[i]
                else:
                    file_mask[i, j] = frame_idx <= frames_cumsum[i]

        for row in range(1, len(frames_cumsum)):
            file_mask[len(frames_cumsum) - row, :] = np.subtract(file_mask[len(frames_cumsum) - row, :],
                                                                 file_mask[len(frames_cumsum) - row - 1, :])

        # préallouer la mémoire avec le nombre total d'images
        valid_id_mask = []
        for frame in range(0, frame_idx.size):
            if any(file_mask[:, frame]):
                valid_id_mask.append(1)
            else:
                valid_id_mask.append(0)

        # si la valeur de cet input n'est pas la default value, on retourne juste h
        if not only_h:
            f = np.zeros((sum(valid_id_mask), len(pixel_idx)), dtype=np.uint16)
        h = np.zeros((sum(valid_id_mask), 4 * int(self.width)), dtype=np.uint8)

        # boucler sur chaque fichier
        for i in range(0, len(frames_cumsum)):
            # calcul de l'offset de base dans la séquence globale (référé à 0)
            # à la première run, l'offset doit être 0
            # à la 2e run, l'offset doit être nframes(fichier 1)
            # à la kième run, l'offset doit être nframes(fichier k-1)
            offset = sum(self.private_length[0: i])

            # extraction des indices d'image liés au fichier courant
            # les lignes de filemask contiennent l'info sur les frames à prendre de chaque fichier, arrangé par ligne
            nb_good_frames = int(sum(file_mask[i, :]))
            counter = 0
            subfile_idx = np.zeros(nb_good_frames, dtype=int)
            for j in range(0, len(file_mask[i, :])):
                if file_mask[i, j] == 1:
                    if frame_idx.size > 1:
                        subfile_idx[counter] = frame_idx[j] - offset
                    else:
                        subfile_idx[counter] = frame_idx - offset
                    counter += 1
            if not subfile_idx.size:
                continue

            # calcul des indices de sortie
            output_local_idx = np.zeros(nb_good_frames, dtype=int)
            counter2 = 0
            for j in range(0, len(file_mask[i, :])):
                if file_mask[i, j]:
                    output_local_idx[counter2] = counter2
                    counter2 += 1

            # création du vecteur de structures contenant les données extraites de l'objet "memmapfile"
            q = [{"Header": []}, {"Data": []}]
            for index in subfile_idx:
                q[0]["Header"].append(self.memmap[i][0]["Header"][index])
                q[1]["Data"].append(self.memmap[i][1]["Data"][index])

            # extraction des en-têtes
            tempu = np.asarray(q[0]["Header"]).reshape((len(q[0]["Header"]), len(q[0]["Header"][0])))
            counter = 0
            for index in output_local_idx:
                h[index, :] = tempu[counter, :]
                counter += 1

            if not only_h:
                # extraction des données
                if len(pixel_idx) == int(self.width) * int(self.height):
                    # méthode rapide lorsque l'image est pleine
                    tempu = np.asarray(q[1]["Data"]).reshape((len(q[1]["Data"]), len(q[1]["Data"][0])))
                    counter = 0
                    for index in output_local_idx:
                        f[index, :] = tempu[counter, :]
                        counter += 1
                else:
                    # méthode lente lorsque seulement une fraction de l'image est lue
                    tempu = q[1]["Data"]
                    for idx_f in range(0, len(tempu)):
                        testxd = np.asarray(tempu[idx_f], dtype=np.int).transpose()[0]
                        f[idx_f, :] = testxd[np.asarray(pixel_idx, dtype=int)]

        h = read_ircam_header_b(h)

        if not only_h:
            return h, f
        else:
            return h

    def fetch(self, frame_idx, pixel_idx=()):
        # frame_idx et pixel_idx semblent être des listes [1, 2, ..., n] où n est le nombre de frames/pixels
        # Lecture des images d'indices "frame_idx", incluant le post-traitement
        # optionnellement, seulement les pixels d'indices "pixel_idx" sont lus

        # lecture des données non traitées
        if len(pixel_idx) == 0:
            # cas général de lecture sans sélection de pixels
            h, d = self.frame(frame_idx)
        else:
            # cas particulier de lecture avec sélection de pixels
            # - méthode plus lente (sauf si tous les pixels sont lus)
            h, d = self.frame(frame_idx, pixel_idx)

        if not len(d):
            return None

        # fin si absence de statuts de pixels saturés / défectueux
        if h["DeviceXMLMajorVersion"][0] < 10 or h["CalibrationMode"][0] == 0:
            # conversion des données
            d = np.asarray(d, dtype=np.float32)
            #   retourne None pour special_pixel_map et special_nonbad_pixel_map pour unpacker les données comme il faut
            return d, h, None, None

        if len(pixel_idx) != 0:
            # validation de rangées complètes
            completerows = min(pixel_idx) % int(self.width) == 0 \
                           and (max(pixel_idx) + 1) % int(self.width) == 0 \
                           and len(pixel_idx) % int(self.width) == 0
            # validation de rangées consécutives
            rows = np.unique(np.floor(pixel_idx / int(self.width)) + 1)
            uniquerow = len(rows) == 1
            if not uniquerow:
                consecutiverows = all(np.diff(rows))
        else:
            completerows = True
            uniquerow = False
            consecutiverows = True

        # initialisation
        time_start = time.time()
        special_pixel_map = np.zeros(d.shape, dtype='uint8')
        special_pixel_map_modd = np.zeros(d.shape, dtype='uint8')
        # traitement des pixels avec status spéciaux

        mask = d > self.highest_valid_value_code
        special_pixel_map[mask] = np.asarray(d[mask] - self.highest_valid_value_code, dtype=np.uint8)
        special_pixel_map_modd[mask] = np.asarray(d[mask] - self.highest_valid_value_code, dtype=np.uint8)

        # pixels considérés comme saturés
        satmap = np.isin(special_pixel_map,
                         [self.saturated_pixel_tag, self.over_calibration_range, self.upper_digital_saturation])

        # pixels qui doivent être remplacé par la valeur minimum du frame
        min_valued_pixel = np.isin(special_pixel_map, [self.lower_digital_saturation, self.under_calibration_range])

        # pixels considérés comme bad
        bpmap = np.logical_or(
            np.isin(special_pixel_map, [self.blank_image_translation, self.bad_emissivity_correction,
                                        self.bad_pixel_tag]),
            np.logical_and(
                special_pixel_map >= self.special_tag_3,
                special_pixel_map <= self.special_tag_9
            )
        )

        # pixels spéciaux mais non bad
        special_nonbad_pixel_map = special_pixel_map_modd
        special_nonbad_pixel_map[bpmap] = 0

        special_pixel_map_modd = None
        del special_pixel_map_modd
        time_end_specialpix = time.time()

        # méthodes d'attribution des pixels avec statut
        spa = self.spassignment_method
        bpa = self.bpassignment_method
        if not ((uniquerow and completerows) or (not uniquerow and completerows and consecutiverows)):
            # rangées incomplètes ou non consécutives, méthode forcée à 'NaN'
            if spa == 'median':
                spa = 'NaN'
            if bpa == 'median':
                bpa = 'NaN'

        # traitement des pixels saturés
        not_special_pixel_map = (1 - special_pixel_map) <= 1
        if spa.lower() == 'no':
            # aucune action n'est requise
            print("no :)")
        elif spa.lower() == 'max':
            # calculer la valeur maximale et minimale (valide) de chaque image
            # - si tous les pixels d'une image sont défectueux ou saturés, alors les valeurs sont forcées à zéro
            max_frame_value = np.amax(np.multiply(d, not_special_pixel_map), 1)
            min_frame_value = np.amin(np.multiply(d, not_special_pixel_map), 1)

            max_frame_value = np.tile(max_frame_value, (d.shape[1], 1))
            max_frame_value = np.transpose(max_frame_value)
            min_frame_value = np.tile(min_frame_value, (d.shape[1], 1))
            min_frame_value = np.transpose(min_frame_value)

            d[satmap] = max_frame_value[satmap]
            d[min_valued_pixel] = min_frame_value[min_valued_pixel]
        elif spa.lower() == 'median':
            # boucler sur chaque image
            # - carte de pixels saturés variant d'une image à l'autre

            # replace special pixel value for filterbadpixel
            max_frame_value = np.amax(np.multiply(d, not_special_pixel_map), 1)
            min_frame_value = np.amin(np.multiply(d, not_special_pixel_map), 1)

            max_frame_value = np.tile(max_frame_value, (d.shape[1], 1))
            max_frame_value = np.transpose(max_frame_value)
            min_frame_value = np.tile(min_frame_value, (d.shape[1], 1))
            min_frame_value = np.transpose(min_frame_value)

            d[satmap] = max_frame_value[satmap]
            d[min_valued_pixel] = min_frame_value[min_valued_pixel]

            for i in range(0, d.shape[0]):
                # utilisation de la médiane des voisins valides
                # - appliqué récursivement pour chaque image
                listsp = np.asarray(np.where(np.logical_or(satmap[i, :], bpmap[i, :] > 0)), dtype=int)[0]
                if len(listsp) == 0:
                    continue
                if not uniquerow:
                    # cas général
                    lascene = d[i, :].astype('int')
                    d[i, :], _, _ = filter_bad_pixels(listsp, int(self.width), int(d.shape[1] / self.width), lascene,
                                                      recurse=True)
                else:
                    # cas d'une seule rangée
                    # - utilisation de "filterBadPixels" avec une rangée dédoublée, car la fonction ne supporte pas les
                    # images n'ayant qu'une seule rangée
                    scene = d[i, :]
                    duplimg = np.append(scene, scene)
                    dupllistsp = np.append(listsp, listsp + int(self.width))
                    duplimg, _, _ = filter_bad_pixels(dupllistsp, int(self.width), 2, duplimg, recurse=True)

                    d[i, :] = duplimg[0: (len(d[i, :]) / 2) - 1]

        elif spa.lower() == 'nan':
            # attribution d'une valeur "NaN"
            # - appliqué plus loin sur les variable "single", car uint16(NaN) = 0
            d = np.asarray(d, dtype=float)
            d[satmap] = np.nan
        else:
            raise UserWarning('SequenceReaderP:fetch:unknownspassignment '
                              '\nSaturated pixels assignment method {} is not supported.'.format(spa))

        # traitement des pixels défectueux
        # - statut de pixel défectueux a préséance sur les autres statuts, ce pourquoi il est appliqué en dernier
        if bpa.lower() == 'no':
            # aucune action n'est requise
            print("no :)")
        elif bpa.lower() == 'median':

            if spa.lower() != 'median' or spa.lower() != 'max':
                max_frame_value = np.amax(np.multiply(d, not_special_pixel_map), 1)
                min_frame_value = np.amin(np.multiply(d, not_special_pixel_map), 1)

                max_frame_value = np.tile(max_frame_value, (d.shape[1], 1))
                max_frame_value = np.transpose(max_frame_value)
                min_frame_value = np.tile(min_frame_value, (d.shape[1], 1))
                min_frame_value = np.transpose(min_frame_value)

                d[satmap] = max_frame_value[satmap]
                d[min_valued_pixel] = min_frame_value[min_valued_pixel]
            else:
                pass  # nothing to do, value already replaced

            # identification des blocs présents
            cbpt = np.unique(h["CalibrationBlockPOSIXTime"])
            # boucler sur chaque bloc
            # - carte de pixels défectueux liée seulement au bloc, donc commune à toutes les
            # images associées à un même bloc
            for cc in range(0, len(cbpt)):
                # utilisation de la médiane des voisins valides
                # - appliquée récursivement
                indices = np.nonzero(h["CalibrationBlockPOSIXTime"] == cbpt[cc])[0]
                listbp = np.nonzero(bpmap[indices[0], :])[0]
                if not uniquerow:
                    # cas général
                    d[indices, :], _, remplacement = filter_bad_pixels(listbp, int(self.width),
                                                                       int(d.shape[1] / self.width), d[indices, :],
                                                                       recurse=True)

                else:
                    # cas d'une seule rangée
                    # - utilisation de "filterBadPixels" avec une rangée dédoublée, car la fonction ne supporte pas les
                    # images n'ayant qu'une seule rangée
                    scene = d[indices, :]
                    duplimg = np.tile(scene, (1, 2))
                    dupllistbp = np.append(listbp, listbp + self.width)
                    duplimg, _, remplacement = filter_bad_pixels(dupllistbp, int(self.width), 2, duplimg,
                                                                 recurse=True)
                    d[indices, :] = duplimg[:, 0: int(duplimg.shape[1] / 2)]
                    remplacement = remplacement[:, 0: int(duplimg.shape[1] / 2)]
                    remplacement = np.mod(remplacement, int(self.width))

                # indication de statut spéciaux pour les pixels auxquels une valeur spéciale a été attribuée
                for i in range(0, len(indices)):
                    special_nonbad_pixel_map[indices[i], :] = special_nonbad_pixel_map[indices[i], remplacement[i, :]]

        elif bpa.lower() == 'nan':
            # attribution d'une valeur "NAN"
            # - appliqué plus loin sur les variables "single", car uint16(NaN) = 0
            d = np.asarray(d, dtype=float)
            d[bpmap] = np.nan
        else:
            raise UserWarning('SequenceReaderP:fetch:unknownbpassignment '
                              '\nBad Pixels assignment method {} is not supported.'.format(bpa))

        # dénormalisation des données
        d = d.astype(np.float32)
        broadcast_dataexp = np.reshape(np.power(float(2), h["DataExp"].astype(np.float32)), (h["DataExp"].shape[0], 1))
        broadcast_dataoffset = np.reshape(h["DataOffset"].astype(np.float32), (h["DataOffset"].shape[0], 1))
        d = d * np.tile(broadcast_dataexp, (1, d.shape[1]))
        d = d + np.tile(broadcast_dataoffset, (1, d.shape[1]))

        # traitement des pixels appliqués spécifiquement sur les variables "single"
        # - car la valeur "NaN" n'existe pas en "uint16"
        if spa.lower() == 'nan':
            # attribution d'une valeur "NaN"
            d[satmap] = np.nan
        if spa.lower() == 'nan':
            # attribution d'une valeur "NaN"
            d[bpmap] = np.nan

        return d, h, special_pixel_map, special_nonbad_pixel_map

    def get_length(self):
        # calcul de la longueur totale
        # - plusieurs longueurs sont présentes en multi-fichier
        value = sum(self.private_length)
        return value
