import numpy as np
import warnings
from TelopsToolbox.utils.defineConstants import define_constants


def brightness_temperature(sigma, l, replace_mode='NaN'):
    """
    Convert a spectral radiance into its equivalent brightness temperature

        T = brightnessTemperature(sigma, L)

        - radiance units [r.u.] = W / (m^2 sr cm^-1)

                                (h c / k) s
                T(s, T) = ---------------------------
                           ln[(2 h c^2 s^3) / L + 1]

        - The size of T is the common size of the input arguments. A scalar input functions as a constant matrix of the
        same size as the other inputs

    Inputs

        sigma [cm^-1]           Wavenumber vector. Nbins x 1
        L     [W/m^2 sr cm^-1]  Real-valued radiance matrix. Nbin x Npixels

        parameter/value
            replace_mode [optional] : 'NaN', 'zeros', 'interp', how to deal with negative radiance values (L < 0).
                                      Default is 'NaN'. 'interp' mode linearly interpolates negative values with the
                                      closest non-negative spectral neighbour bins

    Outputs

        T [K]                   Brightness temperature matrix. Nbin x Npixels

    Special cases:
        sigma < 0  :    an error is produced
        sigma == 0 :    returns NaN for null frequencies
        L == 0     :    returns 0 for zero input radiance
        Re(L) <= 0 :    returns NaN, zeros, of perform linear interpolation for negative input radiance
                        (depends on 'replaceMode' parameter)

    EXAMPLE 1:
        sig = 0:10000              %[cm^-1]
        Tbb = 300                  %[K]
        rad = blackbody(sig, Tbb)  %[watt/m^2 cm^1 sr]

    EXAMPLE 2:
        sig = 0:10000              %[cm^-1]
        rad1 = Blackbody(sig, 300) %[watt/m^2 cm^-1 sr]
        rad2 = Blackbody(sig, 500) %[watt/m^2 cm^-1 sr]
        rad = [rad1;rad2];

        T = BrightnessTemp(sig, rad);

    Copyright Telpos 2013
    """

    replace_modes_possibles = ['NaN', 'nan', 'zeros', 'zero', 'interp']
    if replace_mode not in replace_modes_possibles:
        raise UserWarning("brightness_temperature:replace_mode "
                          "\nInvalid replace_mode")

    # si aucune dimension de L match la longueur de sigma, return error
    if np.all(np.invert(np.equal(len(sigma), l.shape))):
        raise UserWarning("Spectral grid dimension did not match any of the radiance matrix dimensions")

    if (np.less(sigma, 0)).any():
        raise UserWarning("Sigma must be >= 0")

    sz = l.shape
    if (np.equal(sz, 1)).any():
        # orient both vectors in the same direction
        if sz[0] == 1:
            # devient un vecteur ligne
            sigma = sigma.reshape((1, -1))
        else:
            # devient un vecteur colonne
            sigma = sigma.reshape((-1, 1))

    # définir phys_constants
    phys_constants, _ = define_constants()

    # Fundamental constants.:
    light_speed_c = phys_constants["speed_of_light"]["val"]   # [m/s]
    boltzmann_k = phys_constants["boltzmann"]["val"]          # [J/K]
    planck_h = phys_constants["planck"]["val"]                # [J s]
    # planck_c1 = 2 h c^2 ~ 1.191044e-5 [J cm^2/s]
    #                     = 1.191044e-5 [mW/m^2/sr/cm^-4] = 1.191044e-8 [W/m^2/sr/cm^-4]
    planck_c1 = (2.0 * planck_h * (light_speed_c * 100.0)**2) * 1e4
    # planck_c2 = h c / k ~ 1.438769 [cm K]
    planck_c2 = (planck_h * light_speed_c * 100.0 / boltzmann_k)

    # consider only real spectral radiances
    if np.any(np.iscomplex(l)):
        warnings.warn("brightnessTemperature::ImaginaryRadiance\n"
                      "Spectral radiance has imaginary part, only real part is kept.")
        l = np.real(l)

    # replace value if the radiance is non-positive
    k_neg = np.less(l, 0)
    if np.any(k_neg):
        if replace_mode == 'nan' or replace_mode == 'NaN':
            # faut absolument que l.dtype = np.float, sinon l'erreur suivante apparait :
            # ValueError: cannot convert float NaN to integer
            l[k_neg] = np.nan
        elif replace_mode == 'zero' or replace_mode == 'zeros':
            l[k_neg] = 0
        elif replace_mode == 'interp':
            # find pixels requiring replacement
            neg_px = np.argwhere(np.any(k_neg, 0))   # donne les colonnes dans lesquelles j'ai des valeurs négatives
            for i in range(0, len(neg_px)):
                px = neg_px[i]
                if k_neg[0, px]:
                    # first point(s) of the spectrum is(are) negative
                    # - replace with closer non-negative value
                    # doit construire un linspace allant de 0 jusqu'à (ligne - 1), où ligne est le numéro de la ligne
                    # du premier 0 dans la colonne itérée de k_neg
                    not_k_neg = np.invert(k_neg[:, px])
                    ligne = np.argwhere(not_k_neg)[0][0]   # on veut juste la ligne du premier non négatif
                    inl_first = np.linspace(0, ligne - 1, num=ligne, dtype=int)
                    l[inl_first, px] = l[np.amax(inl_first) + 1, px]
                    k_neg[inl_first, px] = 0
                if k_neg[-1, px]:
                    # last point(s) of spectrum is(are) negative
                    # - replace with closer non-negative value
                    print("smilers :)")
                    # doit construire un linspace allant de la ligne de la dernière valeur nulle de k_neg jusqu'au
                    # nombre de lignes de k_neg
                    not_k_neg = np.invert(k_neg[:, px])
                    ligne = np.argwhere(not_k_neg)[-1][0]  # on veut juste la ligne du dernier non négatif
                    inl_last = np.linspace(ligne + 1, len(k_neg[:, px]) - 1, num=len(k_neg[:, px]) - (ligne + 1),
                                           dtype=int)
                    l[inl_last, px] = l[np.amin(inl_last) - 1, px]
                    k_neg[inl_last, px] = 0
                    print("voici l: {}".format(l))
                # middle point(s) of spectrum is(are) negative
                # do linear interpolation between neighbours with non-negative values
                not_k_neg = np.invert(k_neg[:, px])
                not_k_neg_transposed = np.transpose(not_k_neg)[0]
                k_neg_transposed = np.transpose(k_neg[:, px])[0]
                l[k_neg_transposed, px] = np.interp(sigma[not_k_neg], sigma[k_neg[:, px]], l[not_k_neg_transposed, px])

    t_numerator = np.array(planck_c2 * sigma)  # , dtype=np.dtype(float))
    t_deno_log_num = np.array(planck_c1 * np.multiply(np.multiply(sigma, sigma), sigma))  # , dtype=np.dtype(float))
    t_deno_log = np.array(np.divide(t_deno_log_num, l))  # , dtype=np.dtype(float))
    t_denominator = np.array(np.log(t_deno_log + 1))  # , dtype=np.dtype(float))
    t = np.array(np.divide(t_numerator, t_denominator))  # , dtype=np.dtype(float))

    return t
