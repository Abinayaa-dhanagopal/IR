import numpy as np


def get_aoi_indices(f, aoi_in):
    """
    Get indices of an area of interest (AOI) relative to a full frame (F)
    AOI_idx, AOI_out = get_aoi_indices(f, aoi_in)

    Provides the indices of an area of interest (AOI) relative to a full frame (F).

    Usage:
    AOI_idx, _ = getAoiIndices(F, AOI_in)
    AOI_idx, AOI_out = getAoiIndices(F, AOI_in)

    Example:
    ...

    --------------------------------------------------------------------------------------------------------------------
    INPUT VARIABLES:
    f                       : dictionary containing the information relative to the full frame
        ["Width"]           : width of the full frame
        ["Height"]          : height of the full frame
        ["FlipLR"]          : flip left-right flag of the full frame (or .ReverseX)
        ["FlipUD"]          : flip up-down flag of the full frame (or .ReverseY)
    aoi_in                  : dictionary containing the information relative to the area of interest (AOI) in the GUI
                              referential
        ["Width"]           : width of the AOI in the GUI referential
        ["Height"]          : height of the AOI in the GUI referential
        ["OffsetX"]         : horizontal offset of the AOI in the GUI referential (referred to 0)
        ["OffsetY"]         : vertical offset of the AOI in the GUI referntial (referred to 0)
    --------------------------------------------------------------------------------------------------------------------
    OUTPUT VARIABLES:
    aoi_idx                 : vector of indices corresponding to the AOI
    aoi_out                 : dictionary containing the information relative to the area of interest (AOI) in the native
                              referential
        ["Width"]           : width of the AOI in the native referential
        ["Height"]          : height of the AOI in the native referential
        ["OffsetX"]         : horizontal offset of the AOI in the native referential (referred to 0)
        ["OffsetY"]         : vertical offset to the AOI in the native referential (referred to 0)
        ["FlipLR"]          : flip left-right flag of the AOI in the native referential (referred to 0)
        ["FlipUD"]          : flip up-down flag of the AOI in the native referential (referred to 0)
    --------------------------------------------------------------------------------------------------------------------
    INTERNAL VARIABLES:
    aoi                     : dictionary containing the information relative to the area of interest (AOI) in the native
                              referential
        ["Width"]           : width of the AOI in the native referential
        ["Height"]          : height of the AOI in the native referential
        ["OffsetXG"]        : horizontal offset of the AOI in the GUI referential (referred to 0)
        ["OffsetYG"]        : vertical offset of the AOI in the GUI referential (referred to 0)
        ["FlipLR"]          : flip left-right flag of the AOI in the native referential (referred to 0)
        ["FlipUD"]          : flip up-down flag of the AOI in the native referential (referred to 0)
        ["OffsetXN"]        : horizontal offset of the AOI in the native referential (referred to 0)
        ["OffsetYN"]        : vertical offset of the AOI in the native referential (referred to 0)
        ["IndexN"]          : vector of the indices of the AOI in the native referential
        ["xN"]              : vector of the columns of the AOI in the native referential
        ["yN"]              : vector of the rows of the AOI in the native referential

    --------------------------------------------------------------------------------------------------------------------
    Author: Pierre Tremblay ing.
    Translator : BTU
    Company: Telops
    ----- Change Record: -----------------------------------------------------------------------------------------------
    Version     Date            Name    Comment
    0.0         8 AUG 2018      BTU     Creation

    Copyright Telops 2019
    """
    # Initialization

    # set image parameters of the area of interest (AOI)
    aoi = {
        "Width": aoi_in["Width"],
        "Height": aoi_in["Height"],
        "OffsetXG": aoi_in["OffsetX"],
        "OffsetYG": aoi_in["OffsetY"]
    }

    if 'FlipLR' in f:
        aoi["FlipLR"] = f["FlipLR"]
    elif 'ReverseX' in f:
        aoi["FlipLR"] = f["ReverseX"]
    else:
        aoi["FlipLR"] = False

    if 'FlipUD' in f:
        aoi["FlipUD"] = f["FlipUD"]
    elif 'ReverseY' in f:
        aoi["FlipUD"] = f["ReverseY"]
    else:
        aoi["FlipUD"] = False

    # ensure AOI horizontal parameters are valid
    if aoi_in["Width"] < 1:
        raise ValueError("AOI's Width must be >= 1.")
    if aoi_in["OffsetX"] < 0:
        raise ValueError("AOI's Offset must be >= 0.")
    if aoi_in["OffsetX"] > f["Width"] - 1:
        raise ValueError("AOI's offset must be <= {}.".format(f["Width"] - 1))
    if aoi_in["Width"] > f["Width"]:
        raise ValueError("AOI's Width must be <= {}.".format(f["Width"]))
    if aoi_in["OffsetX"] + aoi_in["Width"] > f["Width"]:
        raise ValueError("AOI's Offset + Width must be <= {}.".format(f["Width"]))

    # ensure AOI vertical parameters are valid
    if aoi_in["Height"] < 1:
        raise ValueError("AOI's Height must be >= 1.")
    if aoi_in["OffsetY"] < 0:
        raise ValueError("AOI's OffsetY must be >= 0.")
    if aoi_in["OffsetY"] > f["Height"] - 1:
        raise ValueError("AOI's OffsetY must be <= {}.".format(f["Height"] - 1))
    if aoi_in["Height"] > f["Height"]:
        raise ValueError("AOI's Height must be <= {}.".format(f["Height"]))
    if aoi_in["OffsetY"] + aoi_in["Height"] > f["Height"]:
        raise ValueError("AOI's OffsetY + Height must be <= {}.".format(f["Height"]))

    # Processing
    # set offsets of the area of interest (AOI) in native referential (pre-flipping coordinates)
    aoi["OffsetXN"] = aoi["OffsetXG"] + aoi["FlipLR"] * (f["Width"] - aoi["Width"] - 2 * aoi["OffsetXG"])
    aoi["OffsetYN"] = aoi["OffsetYG"] + aoi["FlipUD"] * (f["Height"] - aoi["Height"] - 2 * aoi["OffsetYG"])

    # set coordinates of the area of interest (AOI) in native referential (pre-flipping coordinates)
    aoi["IndexN"] = np.linspace(0, int(aoi["Width"] * aoi["Height"]) - 1, int(aoi["Width"] * aoi["Height"]), dtype=int)
    aoi["xN"] = np.mod(aoi["IndexN"], aoi["Width"])
    aoi["yN"] = np.floor(aoi["IndexN"] / aoi["Width"])

    # set equivalent coordinates of the are of interest (AOI), as reported in the full image (F) referential in native
    # referential (pre-flipping coordinates)
    fx = aoi["xN"] + aoi["OffsetXN"]
    fy = aoi["yN"] + aoi["OffsetYN"]
    # refer to Eq. (1) of [DUB10]
    aoi_idx = np.array(fx + f["Width"] * fy, dtype=int)

    # set final parameters of the area of interest (AOI)
    aoi_out = {
        "Width": aoi["Width"],
        "Height": aoi["Height"],
        "OffsetX": aoi["OffsetXN"],
        "OffsetY": aoi["OffsetYN"],
        "FlipLR": aoi["FlipLR"],
        "FlipUP": aoi["FlipUD"]
    }

    return aoi_idx, aoi_out


def image_scaling_limits(image_vect, thresh=0.04):
    """
    Calculate a pixel range [clims(1), clims(2)] to be used with the function imagesc(..., clims).
        clims = image_scaling_limits(image_vect, thresh)

            clims(1): thresh*100 percentile
            clims(2): (1-thresh)*100 percentile

        INPUTS :
            image_vect :        A row vector containing the intensity of the pixels.
                                For an image my_image of size (xsize, ysize), vectorialize my)image so that a typical
                                function call resemble
                                    clims = image_scaling_limits(my_image[:])
                                more than one frame may be passed as a matrix of (Nframes x Npixels)

            thresh :            A number between 0 and 0.5. Default is 0.04. See OUTPUTS section (?)

        OUTPUTS :
            clims :             1x2 vector for a single frame, [nframes x 2] for a set of frames matrix

    *** EXAMPLES ***
            clims = image_scaling_limits(my_image_vectorized)
            clims = image_scaling_limits(my_image_vectorized, 0.04)

    Author:  Louis Belhumeur/Telops Inc.

    """
    if len(image_vect.shape) == 1:
        image_vect = np.array([image_vect])

    sort_dim = 1
    nframes = image_vect.shape[0]

    clims = np.zeros((nframes, 2))

    pixval = np.sort(image_vect, sort_dim)
    nb2reject = int(np.floor(thresh * pixval.shape[sort_dim]))
    clims[:, 0] = pixval[:, nb2reject]
    clims[:, 1] = pixval[:, -(1+nb2reject)]

    if np.array_equal(clims[:, 0], clims[:, 1]):
        clims[:, 1] += 1

    return clims


def build_aoi(width, height, offsetx, offsety):
    """
     Construct an AOI dictionary that can be used with getAoiIndices

    :param width
    :param height
    :param offsetx
    :param offsety
    """
    aoi = {"Width": float(width),
           "Height": float(height),
           "OffsetX": float(offsetx),
           "OffsetY": float(offsety)}
    return aoi


def unfold_image(op, img_2d):
    """
    Unfold a formImage() image using the original 1D orientation
        img_1d = unfold_image(op, img_2d)

    This function performs the exact inverse of form_image(op, img_1d).

    INPUTS:
        OP      : a dictionary with the following fields: Width Height, FlipLR, FlipUD (or ReverseX and ReverseY)
        img_2d  : an image matrix as returned by form_image(op, img_1d)

    OUTPUT:
        img_1d  : a NxM data matrix with spatial data along its 2nd dimension (M=HxW)

    Author: Simon Savary/Pierre Tremblay

    Copyright Telops 2010
    """

    if ("FlipUD" in op and op["FlipUD"][0]) or ("ReverseY" in op and op["ReverseY"][0]):
        img_2d = np.flip(img_2d, axis=0)   # [H] x W x N

    if ("FlipLR" in op and op["FlipLR"][0]) or ("ReverseX" in op and op["ReverseX"][0]):
        img_2d = np.flip(img_2d, axis=1)   # H x [W] x N

    # 2D to 1D numpy conversion
    if img_2d.ndim < 3:
        img_1d = np.reshape(img_2d.getH(), (1, -1))
    else:
        img_1d = np.reshape(np.transpose(img_2d, (2, 1, 0)), (img_2d.shape[2], -1))

    return img_1d


def build_frame(*varargin):
    """
    Construct an OP structure that can be used with getAoiIndices

    aoi = buildFrame(width, height, fliplr, flipud)
    aoi = buildFrame(x) % from a matrix
    """

    op = 0

    if len(varargin) == 1:
        # soit un dictionnaire, soit une matrice de données
        h = varargin[0]
        print(type(h))
        if type(h) is dict:
            op = {'Width': h["Width"], 'Height': h["Height"], 'FlipLR': 0, 'FlipUD': 0}
            if 'FlipLR' in h:
                op["FlipLR"] = h['FlipLR']
            if 'FlipUD' in h:
                op["FlipUD"] = h['FlipUD']

        elif type(h) is np.ndarray:
            op = {'Width': h.shape[1], 'Height': h.shape[0], 'FlipLR': 0, 'FlipUD': 0}

        else:
            print("input's type not supported")

    elif len(varargin) == 2:
        op = {'Width': varargin[0], 'Height': varargin[1], 'FlipLR': 0, 'FlipUD': 0}

    elif len(varargin) == 4:
        op = {'Width': varargin[0], 'Height': varargin[1], 'FlipLR': varargin[2], 'FlipUD': varargin[3]}

    else:
        print("the number of inputs, {}, is incorrect. The function accepts only 1, 2 or 4 arguments.".format(
            len(varargin)))

    return op


def form_image(op, img_1d):
    """
    Form a correctly oriented 2D image from its 1D vector version for images.
        img_2d = form_image(op, img_1d)
    :param op: a dictionary with the following keys: "Width", "Height", "FlipLR" (or "ReverseX") and "FlipUD"
               (or "ReverseY")
    :param img_1d: a NxM data matrix with spatial data along its 2nd dimension (M=HxW)
    :return:
        img_2d : a HxWxN image array; if N==1, returns a HxW image

    """
    if type(op['Width']) == float or type(op['Width']) == np.uint16:
        width = int(op['Width'])
        height = int(op["Height"])
        flipx = op.get("FlipLR", False) or op.get("ReverseX", False)
        flipy = op.get("FlipUD", False) or op.get("ReverseY", False)
    else:
        width = op['Width'][0]
        height = op["Height"][0]
        flipx = op.get("FlipLR", [False])[0] or op.get("ReverseX", [False])[0]
        flipy = op.get("FlipUD", [False])[0] or op.get("ReverseY", [False])[0]

    img_2d = np.reshape(img_1d, (-1, height, width))

    if flipx:
        img_2d = np.flip(img_2d, axis=1)   # H x [W] x N

    if flipy:
        img_2d = np.flip(img_2d, axis=0)   # [H] x W x N

    return img_2d
